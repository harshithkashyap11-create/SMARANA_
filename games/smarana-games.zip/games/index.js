export {
  GAMES,
  getEnabledGames,
  getGameById,
  getGameByRoute,
  getGamesByDomain,
  groupGamesByDomain,
  buildDailySession,
} from './registry.js';

export { default as GamesPage } from './GamesPage.jsx';
export { buildGameRoutes, GameScreen, GamesIndexRoute } from './GameRoutes.jsx';

export {
  DDAClient,
  configureDDAClient,
  getDDAClient,
  createLocalStorageQueue,
  createMemoryQueue,
} from './shared/DDAClient.js';

export { GamesI18nProvider, useTranslate } from './shared/i18n.js';
export { EN_MESSAGES } from './shared/translations.en.js';
export {
  COGNITIVE_DOMAINS,
  DDA_ADJUSTMENT,
  DIFFICULTY_MAX,
  DIFFICULTY_MIN,
} from './shared/gameTypes.js';
export { clampDifficulty, applyAdjustment, buildGameMetrics } from './shared/gameMetrics.js';
export { useGameSession } from './shared/useGameSession.js';
