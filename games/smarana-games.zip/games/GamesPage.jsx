import React from 'react';
import { getEnabledGames } from './registry.js';
import { useTranslate } from './shared/i18n.js';
import './shared/games.css';

/**
 * Lists every enabled game straight from the registry.
 *
 * Router-agnostic: pass `onSelectGame` and navigate however the app already
 * does. With react-router that is usually
 * `onSelectGame={(game) => navigate(game.route)}`.
 */
export default function GamesPage({ onSelectGame, games }) {
  const t = useTranslate();
  const available = getEnabledGames(games);

  return (
    <div className="sm-game">
      <header className="sm-game__header">
        <div className="sm-game__headings">
          <h1 className="sm-game__title">{t('games.common.libraryTitle')}</h1>
          <p className="sm-game__instructions">{t('games.common.chooseGame')}</p>
        </div>
      </header>

      <ul className="sm-library">
        {available.map((game) => (
          <li key={game.id}>
            <button
              type="button"
              className="sm-library__card"
              onClick={() => onSelectGame?.(game)}
            >
              <h2 className="sm-library__name">{t(game.nameKey)}</h2>
              <p className="sm-library__description">{t(game.descriptionKey)}</p>
              <span className="sm-library__domain">
                {t(`games.domains.${game.cognitiveDomain}`)}
              </span>
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
