import React from 'react';
import { Route, useNavigate } from 'react-router-dom';
import { GAMES, getEnabledGames } from './registry.js';
import GamesPage from './GamesPage.jsx';

/**
 * Route wiring for react-router v6.
 *
 * Assumption: the app uses react-router-dom v6. If it uses a different router,
 * delete this file and map over `getEnabledGames()` in whatever the app already
 * uses — the registry is the only thing routing needs.
 *
 * Usage inside an existing <Routes> tree:
 *
 *   <Routes>
 *     <Route path="/" element={<Home />} />
 *     {buildGameRoutes({ defaultDifficulty: 1 })}
 *   </Routes>
 */

export function GameScreen({ game, defaultDifficulty = 1, ddaClient, onSessionEnd }) {
  const navigate = useNavigate();
  const GameComponent = game.component;

  return (
    <GameComponent
      difficulty={defaultDifficulty}
      ddaClient={ddaClient}
      onSessionEnd={onSessionEnd}
      onExit={() => navigate('/games')}
    />
  );
}

export function GamesIndexRoute() {
  const navigate = useNavigate();
  return <GamesPage onSelectGame={(game) => navigate(game.route)} />;
}

export function buildGameRoutes({
  games = GAMES,
  defaultDifficulty = 1,
  ddaClient,
  onSessionEnd,
  indexPath = '/games',
} = {}) {
  return [
    <Route key="games-index" path={indexPath} element={<GamesIndexRoute />} />,
    ...getEnabledGames(games).map((game) => (
      <Route
        key={game.id}
        path={game.route}
        element={(
          <GameScreen
            game={game}
            defaultDifficulty={defaultDifficulty}
            ddaClient={ddaClient}
            onSessionEnd={onSessionEnd}
          />
        )}
      />
    )),
  ];
}

export default buildGameRoutes;
