import { createContext, createElement, useContext, useMemo } from 'react';
import { EN_MESSAGES } from './translations.en.js';

/**
 * Thin translation shim.
 *
 * SMARANA does not own a translation system yet, so games call `t(key, vars)`
 * and this module resolves it in three steps:
 *   1. a host-provided translate function (i18next, react-intl, custom) if the
 *      app wraps the games in <GamesI18nProvider translate={t} />
 *   2. the bundled English defaults in translations.en.js
 *   3. a humanised version of the last key segment, so a missing key never
 *      renders as raw dot notation to a patient
 *
 * When you adopt i18next, pass its `t` straight into the provider and delete
 * nothing else.
 */

const I18nContext = createContext(null);

export function lookup(messages, key) {
  return key.split('.').reduce(
    (node, segment) => (node && typeof node === 'object' ? node[segment] : undefined),
    messages,
  );
}

export function interpolate(template, vars) {
  if (!vars) return template;
  return template.replace(/\{(\w+)\}/g, (match, name) => (
    Object.prototype.hasOwnProperty.call(vars, name) ? String(vars[name]) : match
  ));
}

function humanise(key) {
  const last = key.split('.').pop() ?? key;
  const spaced = last.replace(/[_-]/g, ' ').replace(/([a-z])([A-Z])/g, '$1 $2');
  return spaced.charAt(0).toUpperCase() + spaced.slice(1);
}

export function defaultTranslate(key, vars) {
  if (!key) return '';
  const message = lookup(EN_MESSAGES, key);
  if (typeof message === 'string') return interpolate(message, vars);
  return humanise(key);
}

export function GamesI18nProvider({ translate, children }) {
  const value = useMemo(() => {
    if (typeof translate !== 'function') return defaultTranslate;
    return (key, vars) => {
      const result = translate(key, vars);
      // i18next returns the key itself when a translation is missing.
      if (typeof result !== 'string' || result === key) {
        return defaultTranslate(key, vars);
      }
      return result;
    };
  }, [translate]);

  return createElement(I18nContext.Provider, { value }, children);
}

export function useTranslate() {
  return useContext(I18nContext) ?? defaultTranslate;
}
