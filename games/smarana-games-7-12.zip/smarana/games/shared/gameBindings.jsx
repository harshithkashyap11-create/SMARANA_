/**
 * ============================================================================
 * THE ONLY INTEGRATION SEAM FOR GAMES 7-12
 * ============================================================================
 * All six new game components import GameLayout, useTranslation and
 * submitGameMetrics from this file and nothing else from outside their folder.
 *
 * To wire them into SMARANA, replace the three exports below with the project's
 * real ones, e.g.:
 *
 *   export { default as GameLayout } from './GameLayout';
 *   export { useTranslation } from 'react-i18next';
 *   export { submitMetrics as submitGameMetrics } from './ddaClient';
 *
 * The fallbacks here exist so the games run and can be reviewed standalone.
 * Delete them once the real bindings are in place.
 *
 * Required shapes
 * ---------------
 * GameLayout props:
 *   title            string   - already-translated game name
 *   instructions     node     - short instruction line, shown under the title
 *   difficulty       number   - 1-5, rendered as a calm indicator
 *   progress         { current, total }
 *   score            { correct, total }
 *   status           'idle' | 'sending' | 'ok' | 'offline'
 *   onExit           fn       - called when the patient leaves early
 *   footer           node     - optional action row
 *   children         node     - the play area
 *
 * useTranslation() -> { t(key, params?) }
 *
 * submitGameMetrics(payload) -> resolves to -1 | 0 | 1 (or { adjustment })
 * ============================================================================
 */
import React from 'react';

/* ---------------------------------------------------------------- fallback */

export function GameLayout({
  title,
  instructions,
  difficulty,
  progress,
  score,
  status = 'idle',
  onExit,
  footer,
  children,
}) {
  return (
    <section className="sm-game" aria-label={title}>
      <header className="sm-game__header">
        <div>
          <h1 className="sm-game__title">{title}</h1>
          {instructions ? <p className="sm-game__instructions">{instructions}</p> : null}
        </div>
        {onExit ? (
          <button type="button" className="sm-btn sm-btn--quiet" onClick={onExit}>
            Finish
          </button>
        ) : null}
      </header>

      <div className="sm-game__meta" role="status" aria-live="polite">
        {progress ? (
          <span className="sm-game__chip">
            Round {progress.current} of {progress.total}
          </span>
        ) : null}
        {score ? (
          <span className="sm-game__chip">
            Correct {score.correct} of {score.total}
          </span>
        ) : null}
        <span className="sm-game__chip">Level {difficulty}</span>
        {status === 'offline' ? <span className="sm-game__chip sm-game__chip--muted">Saving later</span> : null}
      </div>

      <div className="sm-game__body">{children}</div>
      {footer ? <div className="sm-game__footer">{footer}</div> : null}
    </section>
  );
}

/**
 * Fallback translator: returns the last segment of the key, humanised, and
 * interpolates {{params}}. Real i18n replaces this entirely.
 */
export function useTranslation() {
  const t = React.useCallback((key, params) => {
    if (!key) return '';
    const fallback = params && params.defaultValue ? params.defaultValue : String(key).split('.').pop();
    const words = fallback.replace(/([a-z])([A-Z])/g, '$1 $2').replace(/[_-]/g, ' ');
    const text = words.charAt(0).toUpperCase() + words.slice(1);
    if (!params) return text;
    return text.replace(/\{\{(\w+)\}\}/g, (_, name) => (params[name] != null ? params[name] : ''));
  }, []);
  return { t };
}

/** Fallback DDA transport: no backend, so never adjust difficulty. */
export async function submitGameMetrics(payload) {
  if (typeof console !== 'undefined' && console.debug) console.debug('[SMARANA metrics]', payload);
  return 0;
}
