/**
 * Registry entries for games 7-12.
 *
 * This file does NOT create a second registry. Spread these entries into the
 * existing one, e.g. in games/registry.js:
 *
 *   import { GAMES_7_TO_12 } from './registry.games7to12';
 *   export const GAME_REGISTRY = [ ...existingGames, ...GAMES_7_TO_12 ];
 *
 * If the existing registry is an object keyed by id, use:
 *   GAMES_7_TO_12.reduce((acc, g) => ({ ...acc, [g.id]: g }), existingRegistry)
 *
 * Field names follow the metadata model in the brief. If games 1-6 use
 * different key names (e.g. `titleKey` instead of `nameKey`), rename here -
 * the values are what matter.
 */
import VisualSearch from './visual_search/VisualSearch';
import PatternCompletion from './pattern_completion/PatternCompletion';
import SpatialRecall from './spatial_recall/SpatialRecall';
import AttentionTap from './attention_tap/AttentionTap';
import AssociationGame from './association_game/AssociationGame';
import PersonalMemory from './personal_memory/PersonalMemory';

import * as visualSearchConfig from './visual_search/config';
import * as patternCompletionConfig from './pattern_completion/config';
import * as spatialRecallConfig from './spatial_recall/config';
import * as attentionTapConfig from './attention_tap/config';
import * as associationGameConfig from './association_game/config';
import * as personalMemoryConfig from './personal_memory/config';

export const GAMES_7_TO_12 = [
  {
    id: 'visual_search',
    nameKey: 'games.visualSearch.name',
    descriptionKey: 'games.visualSearch.description',
    cognitiveDomain: 'selective_attention',
    component: VisualSearch,
    config: visualSearchConfig,
    icon: '🔍',
    enabled: true,
    ddaProfile: 'search_efficiency',
    analyticsKey: 'game_visual_search',
    route: '/games/visual-search',
    supportsVoice: false,
    supportsOffline: true,
    minDifficulty: 1,
    maxDifficulty: 5,
    estimatedDurationMin: 4,
  },
  {
    id: 'pattern_completion',
    nameKey: 'games.patternCompletion.name',
    descriptionKey: 'games.patternCompletion.description',
    cognitiveDomain: 'reasoning',
    component: PatternCompletion,
    config: patternCompletionConfig,
    icon: '🧩',
    enabled: true,
    ddaProfile: 'reasoning_accuracy',
    analyticsKey: 'game_pattern_completion',
    route: '/games/pattern-completion',
    supportsVoice: false,
    supportsOffline: true,
    minDifficulty: 1,
    maxDifficulty: 5,
    estimatedDurationMin: 5,
  },
  {
    id: 'spatial_recall',
    nameKey: 'games.spatialRecall.name',
    descriptionKey: 'games.spatialRecall.description',
    cognitiveDomain: 'visuospatial_memory',
    component: SpatialRecall,
    config: spatialRecallConfig,
    icon: '🗺️',
    enabled: true,
    ddaProfile: 'spatial_accuracy',
    analyticsKey: 'game_spatial_recall',
    route: '/games/spatial-recall',
    supportsVoice: false,
    supportsOffline: true,
    minDifficulty: 1,
    maxDifficulty: 5,
    estimatedDurationMin: 5,
  },
  {
    id: 'attention_tap',
    nameKey: 'games.attentionTap.name',
    descriptionKey: 'games.attentionTap.description',
    cognitiveDomain: 'sustained_attention',
    component: AttentionTap,
    config: attentionTapConfig,
    icon: '👆',
    enabled: true,
    ddaProfile: 'reaction_time',
    analyticsKey: 'game_attention_tap',
    route: '/games/attention-tap',
    supportsVoice: false,
    supportsOffline: true,
    minDifficulty: 1,
    maxDifficulty: 5,
    estimatedDurationMin: 4,
  },
  {
    id: 'association_game',
    nameKey: 'games.associationGame.name',
    descriptionKey: 'games.associationGame.description',
    cognitiveDomain: 'associative_memory',
    component: AssociationGame,
    config: associationGameConfig,
    icon: '🔗',
    enabled: true,
    ddaProfile: 'recall_accuracy',
    analyticsKey: 'game_association',
    route: '/games/association',
    supportsVoice: true,
    supportsOffline: true,
    minDifficulty: 1,
    maxDifficulty: 5,
    estimatedDurationMin: 6,
  },
  {
    id: 'personal_memory',
    nameKey: 'games.personalMemory.name',
    descriptionKey: 'games.personalMemory.description',
    cognitiveDomain: 'autobiographical_memory',
    component: PersonalMemory,
    config: personalMemoryConfig,
    icon: '🖼️',
    enabled: true,
    // Higher difficulty = LESS support, so this profile must be read as a
    // support level, not a challenge level.
    ddaProfile: 'support_level',
    analyticsKey: 'game_personal_memory',
    route: '/games/personal-memory',
    supportsVoice: true,
    // Core play works offline; content freshness depends on the Memory Capsule
    // provider's own cache (see personal_memory/sampleData.js).
    supportsOffline: true,
    minDifficulty: 1,
    maxDifficulty: 5,
    estimatedDurationMin: 6,
  },
];

export default GAMES_7_TO_12;
