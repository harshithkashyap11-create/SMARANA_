/**
 * Personal Memory Recall - DEVELOPMENT SAMPLE DATA ONLY.
 *
 * Everything in SAMPLE_MEMORY_ITEMS is invented for local development and demos.
 * No real patient, family member or caregiver information belongs in this file.
 *
 * Production flow:
 *   Caregiver -> Memory Capsule -> Django REST API -> createApiMemoryProvider()
 *
 * To switch to live data, pass a provider into <PersonalMemory dataProvider={...} />.
 * Nothing else in the game needs to change.
 */

export const MEMORY_ITEM_TYPES = { PERSON: 'person', PLACE: 'place' };

/** Canonical item shape the game expects from any provider. */
export function normalizeMemoryItem(raw) {
  return {
    id: String(raw.id),
    type: raw.type === MEMORY_ITEM_TYPES.PLACE ? MEMORY_ITEM_TYPES.PLACE : MEMORY_ITEM_TYPES.PERSON,
    displayName: raw.display_name || raw.displayName || raw.name || '',
    relationship: raw.relationship || null,
    relationshipKey: raw.relationship_key || raw.relationshipKey || null,
    location: raw.location || null,
    note: raw.note || raw.memory || null,
    imageUrl: raw.image_url || raw.imageUrl || null,
    placeholderEmoji: raw.placeholder_emoji || raw.placeholderEmoji || (raw.type === 'place' ? '🏡' : '🧑'),
    pronounKey: raw.pronoun_key || raw.pronounKey || 'games.personalMemory.pronoun.they',
    tags: raw.tags || [],
  };
}

const RAW_SAMPLE = [
  { id: 'sample-p1', type: 'person', name: 'Ananya', relationship: 'Daughter', relationship_key: 'relationships.daughter', location: 'Guwahati', memory: 'Visits on Sunday afternoons and brings pitha.', placeholder_emoji: '👩', pronoun_key: 'games.personalMemory.pronoun.she', tags: ['family'] },
  { id: 'sample-p2', type: 'person', name: 'Bikash', relationship: 'Son', relationship_key: 'relationships.son', location: 'Shillong', memory: 'Taught you to ride a bicycle on the hill road.', placeholder_emoji: '👨', pronoun_key: 'games.personalMemory.pronoun.he', tags: ['family'] },
  { id: 'sample-p3', type: 'person', name: 'Meera', relationship: 'Granddaughter', relationship_key: 'relationships.granddaughter', location: 'Guwahati', memory: 'Loves drawing birds with you.', placeholder_emoji: '👧', pronoun_key: 'games.personalMemory.pronoun.she', tags: ['family'] },
  { id: 'sample-p4', type: 'person', name: 'Rohan', relationship: 'Neighbour', relationship_key: 'relationships.neighbour', location: 'Jorhat', memory: 'Shares the morning newspaper with you.', placeholder_emoji: '🧔', pronoun_key: 'games.personalMemory.pronoun.he', tags: ['friend'] },
  { id: 'sample-p5', type: 'person', name: 'Lily', relationship: 'Sister', relationship_key: 'relationships.sister', location: 'Tezpur', memory: 'You cooked together every festival.', placeholder_emoji: '👵', pronoun_key: 'games.personalMemory.pronoun.she', tags: ['family'] },
  { id: 'sample-l1', type: 'place', name: 'Family Home', location: 'Shillong', memory: 'The family lived here for many years.', placeholder_emoji: '🏡', tags: ['home'] },
  { id: 'sample-l2', type: 'place', name: 'Kamakhya Temple', location: 'Guwahati', memory: 'You visited every year before the rains.', placeholder_emoji: '🛕', tags: ['outing'] },
  { id: 'sample-l3', type: 'place', name: 'Tea Garden', location: 'Jorhat', memory: 'You walked here in the early morning.', placeholder_emoji: '🌿', tags: ['outing'] },
  { id: 'sample-l4', type: 'place', name: 'River Ghat', location: 'Guwahati', memory: 'The family watched the boats from here.', placeholder_emoji: '⛵', tags: ['outing'] },
];

export const SAMPLE_MEMORY_ITEMS = RAW_SAMPLE.map(normalizeMemoryItem);

/** Development provider. Mimics an async API so swapping it in is a one-liner. */
export function createSampleMemoryProvider({ delayMs = 120, items = SAMPLE_MEMORY_ITEMS } = {}) {
  return {
    source: 'sample',
    async getItems() {
      if (delayMs > 0) await new Promise((resolve) => setTimeout(resolve, delayMs));
      return items;
    },
  };
}

/**
 * Production provider. `fetchImpl` defaults to global fetch; `endpoint` should
 * point at the Memory Capsule list endpoint for the current patient.
 */
export function createApiMemoryProvider({ endpoint, fetchImpl, headers = {} } = {}) {
  const doFetch = fetchImpl || (typeof fetch !== 'undefined' ? fetch.bind(globalThis) : null);
  return {
    source: 'api',
    async getItems() {
      if (!doFetch || !endpoint) throw new Error('personal_memory: no fetch implementation or endpoint configured');
      const response = await doFetch(endpoint, { headers: { Accept: 'application/json', ...headers } });
      if (!response.ok) throw new Error(`personal_memory: memory capsule request failed (${response.status})`);
      const payload = await response.json();
      const list = Array.isArray(payload) ? payload : payload.results || payload.items || [];
      return list.map(normalizeMemoryItem);
    },
  };
}

/**
 * Wrap any provider so that cached content is used when the network is down.
 * `cache` is any object with async read()/write(items) - reuse the project's
 * existing offline store rather than inventing a new one.
 */
export function withCacheFallback(provider, cache) {
  if (!cache) return provider;
  return {
    source: `${provider.source}+cache`,
    async getItems() {
      try {
        const items = await provider.getItems();
        if (items && items.length) await cache.write(items);
        return items;
      } catch (error) {
        const cached = await cache.read();
        if (cached && cached.length) return cached;
        throw error;
      }
    },
  };
}
